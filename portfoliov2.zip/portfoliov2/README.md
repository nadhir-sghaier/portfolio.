# Portfolio de Nadhir Sghaier

Un portfolio web moderne et animé showcasing des projets et compétences en développement web et mobile.

## 📁 Structure du projet

```
portfoliov2/
├── index.html          # Page d'accueil principale
├── about.html          # Page À propos
├── projects.html       # Liste complète des projets
├── skills.html         # Liste détaillée des compétences
├── contact.html        # Formulaire de contact
├── styles.css          # Feuille de styles principale
├── profile.jpg         # Photo de profil
└── README.md           # Ce fichier
```

## 🌐 Pages du site

### Accueil (index.html)
- Présentation rapide
- Projets récents (3 projets)
- Compétences principales
- Appels à l'action vers les autres pages

### À propos (about.html)
- Biographie et parcours professionnel
- Philosophie et approche de travail
- Objectifs professionnels
- Intérêts personnels

### Projets (projects.html)
- 6 projets au total avec détails
- Tags de technologies utilisées
- Liens vers les codes source
- Description détaillée de chaque projet

### Compétences (skills.html)
- Compétences organisées par catégories :
  - Frontend (HTML, CSS, JavaScript, React, Vue.js, etc.)
  - Backend (PHP, Node.js, Python, Django, Laravel, etc.)
  - Bases de données (MySQL, PostgreSQL, MongoDB, Firebase)
  - Mobile (React Native, Flutter, Expo)
  - IA & Machine Learning (TensorFlow, OpenCV, etc.)
  - Outils & Technologies (Git, Docker, AWS, etc.)

### Contact (contact.html)
- Formulaire de contact fonctionnel
- Liens de contact directs (email, téléphone)
- Liens vers réseaux sociaux (LinkedIn, GitHub, Twitter, Instagram)
- Intégration avec Formspree pour les emails

## 🎨 Fonctionnalités de design

### Animations
- Animations fluides au chargement (slideInDown, slideInUp, fadeIn, scaleIn)
- Effet neon pulsant sur la photo de profil
- Glow text animé sur les titres
- Hover effects sur les boutons et cartes
- Délais d'animation échelonnés pour effet cascade

### Navigation
- Barre de navigation sticky (toujours visible)
- Liens avec underline effect au survol
- Design responsive et mobile-friendly

### Couleurs
- Palette cyberpunk/neon
- Couleur principale : Cyan (#00ffff)
- Arrière-plan : Noir (#0d0d0d)
- Texte : Gris clair (#f5f5f5)

### Typography
- Police : Poppins (Google Fonts)
- Weights : 300, 500, 700

## 🚀 Utilisation

1. **Structure basique** : Tous les fichiers HTML sont indépendants et peuvent fonctionner localement
2. **Personnalisation** : 
   - Remplacez `profile.jpg` avec votre photo
   - Mettez à jour le formulaire de contact avec votre ID Formspree
   - Modifiez les numéros de téléphone et liens réseaux sociaux

3. **Déploiement** :
   - Netlify : Drag & drop le dossier
   - Vercel : Git push vers GitHub puis import du repo
   - GitHub Pages : Push vers une branche gh-pages

## 📱 Responsive Design

- Mobile : 320px+
- Tablet : 768px+
- Desktop : 1024px+
- Navigation flexible et wrappable
- Grids adaptatifs

## 🔧 Technologies utilisées

- HTML5
- CSS3 (Flexbox, Grid, Animations)
- JavaScript Vanilla (optionnel pour interactions futures)
- Google Fonts (Poppins)
- Formspree (pour le formulaire de contact)

## 📝 Notes

- Le formulaire de contact nécessite une configuration avec Formspree
- Les liens GitHub doivent être mis à jour avec vos vrais repositories
- Les réseaux sociaux peuvent être liés vers vos profils réels

## 🎯 Prochaines améliorations possibles

- [ ] Ajouter JavaScript pour validation de formulaire côté client
- [ ] Implémenter un système de filtrage des projets
- [ ] Ajouter un mode sombre/clair
- [ ] Section blog ou articles
- [ ] Animations parallax au scroll
- [ ] Intégration analytics
- [ ] Service worker pour PWA

---

© 2025 Nadhir Sghaier - Tous droits réservés
